console.log("Hello from Skillsoft!");
